/**
 * WeatherCard.js
 * Sub-component: displays current weather conditions.
 * Tests: sub-component importing ThemeContext from @trops/dash-react
 *        (exercises CJS interop / context merge) + sibling utility.
 */

import React, { useContext } from "react";
import { ThemeContext, FontAwesomeIcon } from "@trops/dash-react";
import {
    convertTemp,
    unitSymbol,
    conditionIcon,
} from "../utils/weatherHelpers";

/**
 * @param {Object} props
 * @param {Object} props.current - Current weather { temp, condition, humidity, windSpeed, feelsLike }
 * @param {string} props.location - Location name
 * @param {"imperial"|"metric"} props.units
 */
export const WeatherCard = ({ current, location, units }) => {
    // Access theme context to verify CJS interop with dash-react
    const themeCtx = useContext(ThemeContext);
    const variant = themeCtx?.themeVariant || "dark";

    const icon = conditionIcon(current.condition);
    const temp = convertTemp(current.temp, units);
    const feelsLike = convertTemp(current.feelsLike, units);
    const symbol = unitSymbol(units);

    return (
        <div className="flex flex-col items-center py-3">
            <p className="text-xs text-white/50 uppercase tracking-wide mb-1">
                {location}
            </p>
            <FontAwesomeIcon
                icon={icon}
                className="h-10 w-10 text-yellow-300 mb-2"
            />
            <p className="text-4xl font-bold text-white">
                {temp}
                <span className="text-lg font-normal text-white/60">
                    {symbol}
                </span>
            </p>
            <p className="text-sm text-white/70 capitalize mt-1">
                {current.condition.replace("-", " ")}
            </p>
            <div className="flex gap-4 mt-3 text-xs text-white/50">
                <span>
                    Feels like {feelsLike}
                    {symbol}
                </span>
                <span>Humidity {current.humidity}%</span>
                <span>Wind {current.windSpeed} mph</span>
            </div>
            {variant === "light" && (
                <p className="text-xs text-white/30 mt-1">Light theme</p>
            )}
        </div>
    );
};
