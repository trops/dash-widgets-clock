/**
 * ForecastRow.js
 * Sub-component: renders a single forecast day row.
 * Tests: sub-component importing FontAwesomeIcon from @trops/dash-react
 *        + sibling utility from ../utils/weatherHelpers.
 */

import React from "react";
import { FontAwesomeIcon } from "@trops/dash-react";
import {
    convertTemp,
    unitSymbol,
    conditionIcon,
    dayLabel,
} from "../utils/weatherHelpers";

/**
 * @param {Object} props
 * @param {Object} props.day - Forecast day data { dayOffset, high, low, condition }
 * @param {"imperial"|"metric"} props.units
 */
export const ForecastRow = ({ day, units }) => {
    const icon = conditionIcon(day.condition);
    const high = convertTemp(day.high, units);
    const low = convertTemp(day.low, units);
    const label = dayLabel(day.dayOffset);
    const symbol = unitSymbol(units);

    return (
        <div className="flex items-center justify-between py-1 border-b border-white/10 last:border-0">
            <span className="w-10 text-sm font-medium text-white/80">
                {label}
            </span>
            <FontAwesomeIcon
                icon={icon}
                className="h-3.5 w-3.5 text-white/60"
            />
            <span className="text-sm text-white/60 capitalize w-24 text-center">
                {day.condition.replace("-", " ")}
            </span>
            <span className="text-sm text-white">
                {high}
                {symbol}
            </span>
            <span className="text-sm text-white/50">
                {low}
                {symbol}
            </span>
        </div>
    );
};
