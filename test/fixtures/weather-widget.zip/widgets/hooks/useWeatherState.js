/**
 * useWeatherState.js
 * Custom hook that provides mock weather state.
 * Tests: custom hook importing React (externalized) from nested hooks/ dir;
 *        uses api.storeData for data persistence.
 */

import { useState, useEffect, useCallback } from "react";

/** Generate deterministic mock weather data based on location string. */
function generateMockData(location) {
    // Simple hash from location string for deterministic variety
    let hash = 0;
    for (let i = 0; i < location.length; i++) {
        hash = (hash << 5) - hash + location.charCodeAt(i);
        hash |= 0;
    }
    const seed = Math.abs(hash);

    const conditions = [
        "sunny",
        "partly-cloudy",
        "cloudy",
        "rain",
        "clear",
        "drizzle",
        "thunderstorm",
        "snow",
        "fog",
        "wind",
    ];

    const baseTemp = 55 + (seed % 30); // 55-84 F range
    const condition = conditions[seed % conditions.length];
    const humidity = 30 + (seed % 50);
    const windSpeed = 3 + (seed % 20);

    const forecast = [];
    for (let i = 0; i < 5; i++) {
        const dayOffset = (seed + i * 7) % 10;
        forecast.push({
            dayOffset: i + 1,
            high: baseTemp + 5 - (dayOffset % 8),
            low: baseTemp - 10 + (dayOffset % 6),
            condition: conditions[(seed + i * 3) % conditions.length],
        });
    }

    return {
        location,
        current: {
            temp: baseTemp,
            condition,
            humidity,
            windSpeed,
            feelsLike: baseTemp - 2 + (seed % 5),
        },
        forecast,
        lastUpdated: new Date().toISOString(),
    };
}

/**
 * Custom hook for managing weather widget state.
 *
 * @param {Object} options
 * @param {string} options.location - City/location string
 * @param {Object} [options.api] - Widget API (injected prop)
 * @param {Function} [options.publishEvent] - Event publisher (injected prop)
 * @returns {{ weather: Object|null, loading: boolean, error: string|null, refresh: Function }}
 */
export function useWeatherState({ location, api, publishEvent }) {
    const [weather, setWeather] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const refresh = useCallback(() => {
        setLoading(true);
        setError(null);

        // Simulate async fetch with 300ms delay
        const timer = setTimeout(() => {
            try {
                const data = generateMockData(location);
                setWeather(data);
                setLoading(false);

                // Persist data via widget API if available
                if (api && typeof api.storeData === "function") {
                    api.storeData(data);
                }

                // Publish refresh event if available
                if (typeof publishEvent === "function") {
                    publishEvent("weatherRefreshed", {
                        location,
                        timestamp: data.lastUpdated,
                    });
                }
            } catch (err) {
                setError("Failed to load weather data");
                setLoading(false);
            }
        }, 300);

        return () => clearTimeout(timer);
    }, [location, api, publishEvent]);

    // Fetch on mount and when location changes
    useEffect(() => {
        const cleanup = refresh();
        return cleanup;
    }, [refresh]);

    return { weather, loading, error, refresh };
}
