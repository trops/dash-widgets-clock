export default {
    name: "WeatherWidget",
    canHaveChildren: false,
    workspace: "weather-workspace",
    author: "Dash Team",
    description:
        "Displays mock weather data. Tests external widget compilation pipeline.",
    icon: "cloud-sun",
    type: "widget",
    providers: [
        {
            type: "openweather",
            required: false,
            credentialSchema: {
                apiKey: {
                    type: "text",
                    displayName: "API Key",
                    instructions:
                        "OpenWeather API key (mock — any value works)",
                    required: true,
                    secret: true,
                },
                baseUrl: {
                    type: "text",
                    displayName: "Base URL",
                    instructions: "API base URL override (optional)",
                    required: false,
                    secret: false,
                },
            },
        },
    ],
    events: ["weatherRefreshed"],
    eventHandlers: ["onExternalEvent"],
    styles: {
        backgroundColor: "bg-sky-900",
        borderColor: "border-sky-700",
    },
    userConfig: {
        title: {
            type: "text",
            defaultValue: "Weather",
            displayName: "Title",
            required: false,
        },
        location: {
            type: "text",
            defaultValue: "San Francisco, CA",
            displayName: "Location",
            required: true,
        },
        units: {
            type: "select",
            defaultValue: "imperial",
            displayName: "Units",
            options: [
                { value: "imperial", displayName: "Fahrenheit" },
                { value: "metric", displayName: "Celsius" },
            ],
        },
        refreshInterval: {
            type: "select",
            defaultValue: "300",
            displayName: "Refresh Interval",
            options: [
                { value: "60", displayName: "1 minute" },
                { value: "300", displayName: "5 minutes" },
                { value: "900", displayName: "15 minutes" },
            ],
        },
    },
};
