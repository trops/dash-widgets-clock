/**
 * WeatherWidget.js
 * Main widget component — imports all sub-modules.
 * Tests: main component importing from nested components/, hooks/, utils/ dirs
 *        + Panel and FontAwesomeIcon from @trops/dash-react.
 *
 * Uses <Panel> instead of <Widget> (Widget is not available via require shim;
 * WidgetFactory already wraps external widgets in error boundary/context).
 */

import React from "react";
import { Panel, FontAwesomeIcon } from "@trops/dash-react";
import { WeatherCard } from "./components/WeatherCard";
import { ForecastRow } from "./components/ForecastRow";
import { useWeatherState } from "./hooks/useWeatherState";
import { unitSymbol } from "./utils/weatherHelpers";

const WeatherWidget = (props) => {
    const {
        // User config (from .dash.js defaults / edit panel)
        title = "Weather",
        location = "San Francisco, CA",
        units = "imperial",
        refreshInterval = "300",
        // Injected by WidgetFactory
        api,
        publishEvent,
        selectedProviders,
        ...rest
    } = props;

    const { weather, loading, error, refresh } = useWeatherState({
        location,
        api,
        publishEvent,
    });

    return (
        <Panel {...rest}>
            {/* Header */}
            <div className="flex items-center justify-between px-3 pt-3 pb-1">
                <div className="flex items-center gap-2">
                    <FontAwesomeIcon
                        icon="cloud-sun"
                        className="h-4 w-4 text-white/70"
                    />
                    <h3 className="text-sm font-semibold text-white">
                        {title}
                    </h3>
                </div>
                <button
                    onClick={refresh}
                    className="text-white/40 hover:text-white/80 transition-colors"
                    title="Refresh"
                >
                    <FontAwesomeIcon
                        icon="arrows-rotate"
                        className={`h-3 w-3 ${loading ? "animate-spin" : ""}`}
                    />
                </button>
            </div>

            {/* Content */}
            <div className="px-3 pb-3">
                {loading && !weather && (
                    <div className="flex items-center justify-center py-8">
                        <FontAwesomeIcon
                            icon="spinner"
                            className="h-5 w-5 text-white/40 animate-spin"
                        />
                    </div>
                )}

                {error && (
                    <div className="text-center py-4">
                        <p className="text-red-400 text-sm">{error}</p>
                        <button
                            onClick={refresh}
                            className="text-xs text-white/50 hover:text-white/80 mt-2 underline"
                        >
                            Try again
                        </button>
                    </div>
                )}

                {weather && (
                    <>
                        <WeatherCard
                            current={weather.current}
                            location={weather.location}
                            units={units}
                        />

                        {/* Divider */}
                        <div className="border-t border-white/10 my-2" />

                        {/* Forecast header */}
                        <div className="flex items-center justify-between mb-1">
                            <p className="text-xs text-white/40 uppercase tracking-wide">
                                5-Day Forecast
                            </p>
                            <p className="text-xs text-white/30">
                                {unitSymbol(units)}
                            </p>
                        </div>

                        {/* Forecast rows */}
                        {weather.forecast.map((day, i) => (
                            <ForecastRow key={i} day={day} units={units} />
                        ))}

                        {/* Footer */}
                        <p className="text-xs text-white/20 text-center mt-2">
                            Last updated:{" "}
                            {new Date(weather.lastUpdated).toLocaleTimeString()}
                        </p>
                    </>
                )}
            </div>
        </Panel>
    );
};

export default WeatherWidget;
