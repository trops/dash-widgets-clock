/**
 * weatherHelpers.js
 * Pure utility functions for weather data formatting.
 * Tests: non-React utility bundled from nested utils/ directory.
 */

/**
 * Convert temperature between Fahrenheit and Celsius.
 * @param {number} tempF - Temperature in Fahrenheit
 * @param {"imperial"|"metric"} units
 * @returns {number} Converted (and rounded) temperature
 */
export function convertTemp(tempF, units) {
    if (units === "metric") {
        return Math.round(((tempF - 32) * 5) / 9);
    }
    return Math.round(tempF);
}

/**
 * Get the unit symbol string.
 * @param {"imperial"|"metric"} units
 * @returns {string}
 */
export function unitSymbol(units) {
    return units === "metric" ? "\u00B0C" : "\u00B0F";
}

/**
 * Map a weather condition string to a FontAwesome icon name.
 * @param {string} condition
 * @returns {string} FontAwesome icon name (solid set)
 */
export function conditionIcon(condition) {
    const map = {
        sunny: "sun",
        clear: "sun",
        "partly-cloudy": "cloud-sun",
        cloudy: "cloud",
        overcast: "cloud",
        rain: "cloud-showers-heavy",
        drizzle: "cloud-rain",
        thunderstorm: "bolt",
        snow: "snowflake",
        fog: "smog",
        wind: "wind",
    };
    return map[condition] || "cloud-sun";
}

/**
 * Get a short day-of-week label from a day offset (0 = today).
 * @param {number} offset - Days from today (0-6)
 * @returns {string} Three-letter day label
 */
export function dayLabel(offset) {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const today = new Date();
    today.setDate(today.getDate() + offset);
    return days[today.getDay()];
}
