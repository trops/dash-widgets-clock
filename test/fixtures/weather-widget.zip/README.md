# Weather Widget (Test Fixture)

A structurally complex test widget used to verify the external widget compilation pipeline. Exercises esbuild bundling of relative imports from nested directories into a single CJS output.

## Structure

```
weather-widget/
├── package.json
├── README.md
└── widgets/
    ├── WeatherWidget.js              # Main component — imports all sub-modules
    ├── WeatherWidget.dash.js         # Config: providers, events, eventHandlers, userConfig, styles
    ├── components/
    │   ├── WeatherCard.js            # Sub-component: current conditions (imports ThemeContext)
    │   └── ForecastRow.js            # Sub-component: single forecast row
    ├── hooks/
    │   └── useWeatherState.js        # Custom hook: mock weather state + api.storeData
    └── utils/
        └── weatherHelpers.js         # Pure utilities: temp conversion, icon mapping
```

## Test Matrix

| File                    | What it tests                                                                               |
| ----------------------- | ------------------------------------------------------------------------------------------- |
| `weatherHelpers.js`     | Non-React utility bundled from nested `utils/` dir                                          |
| `useWeatherState.js`    | Custom hook importing `react` (externalized) from nested `hooks/` dir; uses `api.storeData` |
| `ForecastRow.js`        | Sub-component importing `FontAwesomeIcon` from `@trops/dash-react` + sibling utility        |
| `WeatherCard.js`        | Sub-component importing `ThemeContext` from `@trops/dash-react` (CJS interop)               |
| `WeatherWidget.js`      | Main component importing all 4 sub-modules + `Panel`, `FontAwesomeIcon` from dash-react     |
| `WeatherWidget.dash.js` | Credential provider, events, eventHandlers, 4 userConfig fields (text + select), styles     |

## Verification

1. Install widget ZIP via Settings
2. `npm run dev`
3. Widget sidebar: WeatherWidget with `openweather` provider badge, `1 event, 1 handler` badge
4. Add to dashboard: renders weather card with mock data (current conditions + 5-day forecast)
5. Edit panel: 4 config fields — Title, Location, Units, Refresh Interval
6. Change Units to Celsius: temps re-render in °C
7. Console: no bundle evaluation errors
